avg_rain=read.csv(file=file.choose())
avg_rain
plot(avg_rain)
avg_rainTS=ts(avg_rain[,2],start=c(2014,1),frequency=12)
avg_rainTS
plot(avg_rainTS)
library(ggplot2)
TSDecompose<-decompose(avg_rainTS, type='multiplicative')
TSDecompose
plot(TSDecompose)
